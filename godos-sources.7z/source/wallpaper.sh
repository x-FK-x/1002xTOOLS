#!/bin/bash

set -e

WALLPAPER_PATH="/godos/GODOS.png"

# Prüfen, ob das Wallpaper existiert
if [[ ! -f "$WALLPAPER_PATH" ]]; then
    echo "❌ Wallpaper not found: $WALLPAPER_PATH"
    exit 1
fi

echo "✅ Setting default KDE wallpaper to $WALLPAPER_PATH for all users..."

# Funktion zum Setzen des Wallpapers für einen bestimmten User
set_wallpaper_for_user() {
    USERNAME="$1"
    USERHOME=$(eval echo "~$USERNAME")
    CONFIG_FILE="$USERHOME/.config/plasma-org.kde.plasma.desktop-appletsrc"

    mkdir -p "$(dirname "$CONFIG_FILE")"

    # Eintrag setzen oder überschreiben
    grep -q "\[Containments\]\[1\]\[Wallpaper\]\[org.kde.image\]\[General\]" "$CONFIG_FILE" 2>/dev/null || echo "[Containments][1][Wallpaper][org.kde.image][General]" >> "$CONFIG_FILE"
    sed -i "/^\[Containments\]\[1\]\[Wallpaper\]\[org.kde.image\]\[General\]/,/^\[.*\]/s|^Image=.*|Image=file://$WALLPAPER_PATH|" "$CONFIG_FILE" || \
        echo "Image=file://$WALLPAPER_PATH" >> "$CONFIG_FILE"

    chown "$USERNAME":"$USERNAME" "$CONFIG_FILE"
    echo "✅ Wallpaper set for $USERNAME"
}

# Für alle realen Nutzer (UID >= 1000)
for USER in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
    set_wallpaper_for_user "$USER"
done

# Optional: auch für /etc/skel (neue Benutzer)
SKEL_CONFIG="/etc/skel/.config/plasma-org.kde.plasma.desktop-appletsrc"
mkdir -p "$(dirname "$SKEL_CONFIG")"
cat > "$SKEL_CONFIG" <<EOF
[Containments][1][Wallpaper][org.kde.image][General]
Image=file://$WALLPAPER_PATH
EOF

echo "✅ Wallpaper set in /etc/skel for future users"

