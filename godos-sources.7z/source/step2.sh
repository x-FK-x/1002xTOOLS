#!/bin/bash

set -e

echo "=== Replacing KDE File Manager with Caja system-wide ==="

# 1. Entferne Dolphin und andere KDE-Apps
echo "Removing Dolphin and optional KDE apps..."
apt purge -y \
    dolphin \
    kwrite \
    kwalletmanager \
    konqueror \
    khelpcenter \
    sweeper \
    kget \
    kdeconnect \
    dragonplayer \
    okular || true

apt autoremove -y

# 2. Installiere Caja
echo "Installing Caja..."
apt install -y caja

# 3. Setze Caja global als Standard-Dateimanager
echo "Setting Caja as default file manager system-wide..."
mkdir -p /etc/xdg
cat > /etc/xdg/mimeapps.list <<EOF
[Default Applications]
inode/directory=caja.desktop
EOF

echo "=== Done. Caja is now the default file manager for all users. ==="

