#!/bin/bash
cd /godos/source
wget -O refractainstaller-base.deb https://downloads.sourceforge.net/project/refracta/tools/refractainstaller-base_9.6.6_all.deb
wget -O refractainstaller-gui.deb https://downloads.sourceforge.net/project/refracta/tools/refractainstaller-gui_9.6.6_all.deb
sudo dpkg -i refractainstaller-base.deb
sudo dpkg -i refractainstaller-gui.deb
sudo apt install -f -y
rm refractainstaller-base.deb
rm refractainstaller-gui.deb
